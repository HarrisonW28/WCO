# User Guide — WooCommerce Case Opening (v0.5)

## Opening a Case
1. Go to the page with the `[wco_case]` shortcode.  
2. Click **Open Case** to start the spin.  
3. Watch the reel spin under the red pointer.  
4. The prize under the pointer when the reel stops is your reward.  
5. A modal will show your prize and a button to view it.

## Prize Access
- **Product Win**: Opens your WooCommerce order page.  
- **Coupon Win**: Opens the Rewards page (`/my-account/rewards`).  

## Visual Indicators
- 🔺 Red arrow = where the reel stops (your prize)  
- ✨ Subtle glow = highlights the winning slot  
- 🪟 Modal = confirmation and action buttons