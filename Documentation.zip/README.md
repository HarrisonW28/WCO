# WooCommerce Case Opening Plugin

**Version:** 0.5  
**Requires at least:** 5.8  
**Tested up to:** 6.6  
**WC requires at least:** 5.0  
**WC tested up to:** 8.1

## Description
WooCommerce Case Opening allows store owners to create loot-box style product cases where customers can open cases to win products, coupons, or rewards.

Version **0.5** introduces major usability enhancements:
- 🎯 Always-visible arrow pointer above spinner  
- ✨ Subtle glow highlight around the winning prize  
- 🪟 Prize modal with "View Prize" and "Close" options  
- 🔗 Smart redirects: coupons → `/my-account/rewards`, products → order page  
- 📜 **Win Log** page in **WooCommerce → Case Opening → Win Log** (view recent wins)  
- ⚙️ Global options in **Settings → WCO**  
- 🧩 Non-destructive overlay enhancements layered on original v0.4.2

## Features
| Feature | Description | Access |
|---------|-------------|--------|
| **Case Creation** | Define cases as WooCommerce products with configurable loot items. | WooCommerce → Case Opening → Add New Case |
| **Loot Configuration** | Add multiple products or coupons with odds for each case. | Product edit → Product Data → Case Product → Case Items |
| **Frontend Spinner** | Horizontal reel spinner to display case opening animation. | `[wco_case id="123"]` shortcode |
| **Arrow Pointer** | Always-visible arrow to indicate prize won. | Automatic |
| **Glow Highlight** | Subtle pulsing glow effect on winning prize. | Automatic |
| **Prize Modal** | Pops up after spin completes, showing details of prize. | Automatic |
| **Redirect Links** | "View Prize" in modal links to order page or Rewards page. | Automatic |
| **Win Log** | View a table of win events for monitoring. | WooCommerce → Case Opening → Win Log |
| **Global Settings** | Control UI enhancements and behavior. | Settings → WCO |

## Shortcodes
- `[wco_case id="123"]` — render a case spinner for case product ID 123.  

## Installation
1. Upload the plugin folder to `/wp-content/plugins/`  
2. Activate via **Plugins → Installed Plugins**  
3. Configure cases under **WooCommerce → Case Opening → Add New Case**  
4. Insert with `[wco_case id="123"]` shortcode  

## Changelog
### 0.5
- Added arrow overlay pointer above spinner  
- Added subtle glow effect on winning slot  
- Added prize modal with close & redirect options  
- Added **Win Log** page and **Settings → WCO** docs  
- Improved spinner reliability (no blanks, consistent results)

### 0.4.2
- Previous stable release