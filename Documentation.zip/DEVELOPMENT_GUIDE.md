# Developer Guide — WooCommerce Case Opening (v0.5)

## Code Structure
- `woocommerce-case-opening.php` — main loader file  
- `includes/class-wco-core.php` — core logic (AJAX, prize assignment, orders)  
- `assets/js/wco-frontend.js` — original spinner + frontend logic  
- `assets/css/wco-frontend.css` — core spinner styling  
- `assets/js/wco-enhancements.js` — non-destructive overlay enhancements  
- `assets/css/wco-enhancements.css` — arrow, glow, modal styling  
- `includes/class-wco-enhanced-frontend.php` — enqueues enhancement assets

## Enhancement Strategy (v0.5)
- Enqueue additional CSS/JS without removing original code.  
- Hook into `ajaxSuccess` to detect the prize result and update UI.  
- Inject pointer, glow, and modal dynamically after spin.

## Hooks & Filters Reference
- **`wco_case_result`** (action/filter): Prize result array after server-side determination.  
  - Extend to log to external systems or modify UI payload.  
- **AJAX actions:** `wp_ajax_wco_open_case`, `wp_ajax_nopriv_wco_open_case`  
  - Server endpoint for case opening. Attach callbacks/loggers as needed.

## Win Log (Admin)
- Admin page: **WooCommerce → Case Opening → Win Log**.  
- Store implementations typically use a custom table or postmeta to record: user, case, prize, type, reference (order/coupon), timestamp.  
- If you need exports, register a custom admin action or add a `download` nonce to stream CSV.

## Extending
- Front-end: extend `assets/js/wco-enhancements.js` (do not remove existing lines; add new behavior).  
- Back-end: extend via hooks; avoid editing core files when distributing updates.