<?php
/**
 * Plugin Name: WooCommerce Case Opening
 * Description: Award keys on WooCommerce purchases (default: every £10) to open weighted prize cases with a spinner. Includes admin prize builder, wins & fulfillment, key sales toggle, and My Account rewards tab.
 * Version: 0.4.2
 * Author: Harrison Warburton
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * License: GPLv2 or later
 * Text Domain: woocommerce-case-opening
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WCO_VERSION', '0.4.2' );
define( 'WCO_PATH', plugin_dir_path( __FILE__ ) );
define( 'WCO_URL',  plugin_dir_url( __FILE__ ) );

register_activation_hook( __FILE__, function() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $table = $wpdb->prefix . 'wco_wins';
    $sql = "CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        case_id BIGINT UNSIGNED DEFAULT 0,
        prize_label VARCHAR(255) NOT NULL,
        prize_type VARCHAR(50) NOT NULL,
        prize_meta LONGTEXT NULL,
        order_id BIGINT UNSIGNED DEFAULT 0,
        fulfilled TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY fulfilled (fulfilled)
    ) {$charset_collate};";

    $table2 = $wpdb->prefix . 'wco_key_grants';
    $sql2 = "CREATE TABLE {$table2} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        order_id BIGINT UNSIGNED NOT NULL,
        keys_awarded SMALLINT UNSIGNED NOT NULL,
        reason VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY order_id (order_id)
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
    dbDelta( $sql2 );

    // Refresh permalinks (for My Account /rewards endpoint)
    if ( function_exists( 'flush_rewrite_rules' ) ) flush_rewrite_rules();
});

register_deactivation_hook( __FILE__, function() {
    if ( function_exists( 'flush_rewrite_rules' ) ) flush_rewrite_rules();
});

require_once WCO_PATH . 'includes/class-wco-core.php';
require_once WCO_PATH . 'includes/class-wco-admin.php';
require_once WCO_PATH . 'includes/class-wco-account.php';

add_action( 'plugins_loaded', function() {
    if ( class_exists( 'WooCommerce' ) ) {
        WCO_Core::instance();
        WCO_Admin::instance();
        WCO_Account::instance();
    } else {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>WooCommerce Case Opening</strong> requires WooCommerce to be installed and active.</p></div>';
        });
    }
});
