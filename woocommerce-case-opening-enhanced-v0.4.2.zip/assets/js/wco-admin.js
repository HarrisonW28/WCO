(function($){
    function rebuild(){
        var field = $('#wco_prizes_json');
        var data = [];
        $('#wco-prize-builder .row').each(function(){
            var $r = $(this);
            data.push({
                label: $r.find('.p-label').val(),
                type:  $r.find('.p-type').val(),
                weight: parseInt($r.find('.p-weight').val() || '0', 10),
                value: parseFloat($r.find('.p-value').val() || '0'),
                product_id: parseInt($r.find('.p-product').val() || '0', 10),
                expires_days: parseInt($r.find('.p-expires').val() || '0', 10)
            });
        });
        field.val(JSON.stringify(data));
    }
    function row(prize){
        prize = prize || {label:'',type:'coupon_fixed_cart',weight:10,value:'',product_id:'',expires_days:''};
        var html = '<div class="row">'
            + '<input class="p-label" type="text" placeholder="Label" value="'+ (prize.label||'') +'"/>'
            + '<select class="p-type">'
            + '<option value="coupon_fixed_cart">Coupon (Fixed)</option>'
            + '<option value="coupon_percent">Coupon (%)</option>'
            + '<option value="product">Product</option>'
            + '<option value="credit">Credit (Fixed Coupon)</option>'
            + '</select>'
            + '<input class="p-weight" type="number" min="0" placeholder="Weight" value="'+ (prize.weight||0) +'"/>'
            + '<input class="p-value" type="number" step="0.01" placeholder="Value/Percent" value="'+ (prize.value||'') +'"/>'
            + '<input class="p-product" type="number" placeholder="Product ID" value="'+ (prize.product_id||'') +'"/>'
            + '<input class="p-expires" type="number" min="0" placeholder="Expires (days)" value="'+ (prize.expires_days||'') +'"/>'
            + '<button type="button" class="button link-delete">Remove</button>'
            + '</div>';
        var $el = $(html);
        $el.find('.p-type').val(prize.type||'coupon_fixed_cart');
        return $el;
    }
    $(function(){
        var $wrap = $('#wco-prize-builder');
        if (!$wrap.length) return;
        var initial = $('#wco_prizes_json').val();
        var data = [];
        try { data = JSON.parse(initial||'[]'); } catch(e){ data=[]; }
        var $list = $('<div class="rows"></div>');
        data.forEach(function(p){ $list.append(row(p)); });
        var $add = $('<p><button type="button" class="button">Add prize</button></p>');
        $wrap.append($list).append($add);

        $wrap.on('click','.button', function(){
            $list.append(row());
            rebuild();
        });
        $wrap.on('input change','.row input, .row select', rebuild);
        $wrap.on('click','.link-delete', function(){
            $(this).closest('.row').remove();
            rebuild();
        });
    });
})(jQuery);
