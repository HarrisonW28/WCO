
/* Admin-only preview trigger */
jQuery(function($){
    $(document).on('click', '#wco-enh-preview', function(e){
        e.preventDefault();
        if (typeof window.WCO_ENH_previewWin === 'function') {
            window.WCO_ENH_previewWin();
        } else {
            alert('Preview unavailable. Ensure enhancements are enabled and assets loaded.');
        }
    });
});
