
/* global WCO, WCO_ENH, jQuery */
(function($){
    // Mark widget as enhanced
    $(function(){ $('.wco-widget').addClass('wco-enhanced'); });

    // === v10 Horizontal-only Ghost Spinner ===
    function buildGhostOverlay_h(prize){
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-widget .wco-spinner');
        if (!track.length) return null;
        var vp = track.closest('.wco-reel-viewport');
        if (!vp.length) vp = track.parent();

        // Gather items, filter out "nothing"
        var raw = track.children().toArray();
        var filtered = raw.filter(function(el){
            var lab = extractLabelFromItem(el);
            return lab && !/nothing/i.test(lab);
        });
        if (!filtered.length) filtered = raw;
        if (!filtered.length) return null;

        // Overlay ghost
        vp.addClass('wco-enh-ghost-active');
        var wrap = $('<div class="wco-enh-ghost-wrap"></div>').appendTo(vp);
        var ghost = $('<div class="wco-enh-ghost-track"></div>').appendTo(wrap);

        // Clone items ×5
        var nodes = [];
        for (var r=0; r<5; r++){
            filtered.forEach(function(el){
                var $c = $(el).clone(true, true);
                var id = $(el).data('id') || $(el).attr('data-id');
                if (id) $c.attr('data-id', id);
                var lab = $(el).attr('data-label') || $(el).data('label') || $(el).attr('data-name');
                if (lab) $c.attr('data-label', lab);
                ghost.append($c);
                nodes.push($c.get(0));
            });
        }
        ghost.children().css({ display: 'inline-block', verticalAlign: 'top' });
        vp.find('.wco-pointer').remove();
        vp.append('<div class="wco-pointer" aria-hidden="true"></div>');
        return { viewport: vp, ghostWrap: wrap, ghostTrack: ghost, nodes: nodes };
    }

    function findMatchingIndex_h(nodes, prize){
        var wanted = (prize && (prize.label || prize.prize_label || prize.name)) || '';
        var wantedLower = String(wanted).toLowerCase().trim();
        var prizeId = (prize && (prize.product_id || prize.coupon_id || prize.id || prize.prize_id));
        var idx = -1;
        for (var i=nodes.length-1; i>=0; i--){
            var $el = $(nodes[i]);
            var id  = ($el.data('id') || $el.attr('data-id') || '').toString();
            var lab = extractLabelFromItem(nodes[i]).toLowerCase().trim();
            if (wantedLower && lab === wantedLower){ idx = i; break; }
            if (prizeId && id && String(prizeId) === String(id)){ idx = i; break; }
        }
        return idx;
    }

    function animateGhost_h(ctx, targetIndex, done){
        var vp = ctx.viewport, ghost = ctx.ghostTrack, nodes = ctx.nodes;
        if (targetIndex < 0) targetIndex = Math.floor(nodes.length/2);
        var target = $(nodes[targetIndex]).get(0);
        var rect = target.getBoundingClientRect();
        var vpRect = vp.get(0).getBoundingClientRect();
        var slotW = rect.width || 64;
        var targetLeft = target.offsetLeft;
        var centerOffsetX = (vpRect.width/2) - (slotW/2);
        var stopX = -(targetLeft - centerOffsetX);
        ghost.css('transition', 'transform 4s cubic-bezier(.17,.67,.83,.67)');
        ghost.get(0).offsetHeight;
        ghost.css('transform', 'translate(' + stopX + 'px,0)');
        var handled = false;
        ghost.one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function(){
            if (handled) return;
            handled = true;
            if (typeof done === 'function') done();
        });
        setTimeout(function(){ if (!handled){ handled = true; if (typeof done === 'function') done(); } }, 4500);
    }

    function cleanupGhost_h(ctx){
        if (!ctx) return;
        ctx.viewport.removeClass('wco-enh-ghost-active');
        ctx.ghostWrap.remove();
    }

    function spinHorizontal_v10(prize, payload, done){
        $('.wco-enh-ghost-wrap').remove();
        $('.wco-widget .wco-pointer').remove();
        var ctx = buildGhostOverlay_h(prize);
        if (!ctx){ if (typeof done === 'function') done(); return; }
        var index = findMatchingIndex_h(ctx.nodes, prize);
        animateGhost_h(ctx, index, function(){
            if (typeof done === 'function') done();
            setTimeout(function(){ cleanupGhost_h(ctx); }, 300);
        });
    }


    // === v9 Ghost Overlay Spinner (deterministic visual landing) ===
    function findViewportAndTrack(){
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-widget .wco-spinner');
        if (!track.length) track = $('.wco-widget [data-wco-track]');
        if (!track.length) return null;

        var vp = track.closest('.wco-reel-viewport');
        if (!vp.length) vp = track.parent();
        return { viewport: vp, track: track };
    }

    function getOrientation(vp, sampleItem){
        // Determine vertical (stacked top-to-bottom) vs horizontal
        var rect = sampleItem.getBoundingClientRect();
        return (rect.height >= rect.width) ? 'vertical' : 'horizontal';
    }

    function buildGhostOverlay(prize){
        var ctx = findViewportAndTrack();
        if (!ctx) return null;
        var vp = ctx.viewport, track = ctx.track;

        // Gather items (skip "nothing")
        var raw = track.children().toArray();
        var filtered = raw.filter(function(el){
            var lab = extractLabelFromItem(el);
            return lab && !/nothing/i.test(lab);
        });
        if (!filtered.length) filtered = raw;

        if (!filtered.length) return null;
        var orient = getOrientation(vp.get(0), filtered[0]);

        // Wrap and track
        vp.addClass('wco-enh-ghost-active');
        var wrap = $('<div class="wco-enh-ghost-wrap"></div>').appendTo(vp);
        var ghost = $('<div class="wco-enh-ghost-track"></div>').appendTo(wrap);

        // Size and layout
        var vpRect = vp.get(0).getBoundingClientRect();
        ghost.css({ left: 0, top: 0, width: vpRect.width, height: vpRect.height });

        // Build repeated items (×5) into ghost
        var REPEATS = 5;
        var nodes = [];
        for (var r=0; r<REPEATS; r++){
            filtered.forEach(function(el){
                var $c = $(el).clone(true, true);
                // Ensure labels/ids retained
                var id = $(el).data('id') || $(el).attr('data-id');
                if (id) $c.attr('data-id', id);
                var lab = $(el).attr('data-label') || $(el).data('label') || $(el).attr('data-name');
                if (lab) $c.attr('data-label', lab);
                ghost.append($c);
                nodes.push($c.get(0));
            });
        }

        // Stack layout: ensure vertical stacking if vertical, else inline-block for horizontal
        if (orient === 'vertical'){
            ghost.children().css({ display: 'block' });
        } else {
            ghost.children().css({ display: 'inline-block', verticalAlign: 'top' });
            ghost.css({ whiteSpace: 'nowrap' });
        }

        // Pointer alignment
        ensureAdaptivePointer(vp, orient);

        return { viewport: vp, ghostWrap: wrap, ghostTrack: ghost, nodes: nodes, orientation: orient };
    }

    function ensureAdaptivePointer(vp, orient){
        // Remove existing pointer first to avoid duplicates
        vp.find('.wco-pointer').remove();
        if (orient === 'vertical'){
            vp.append('<div class="wco-pointer v" aria-hidden="true"></div>');
            // Also optional center highlight
            var slotH = estimateSlotSize(vp, 'vertical');
            if (!vp.find('.wco-enh-center-highlight').length && slotH){
                var hl = $('<div class="wco-enh-center-highlight"></div>').appendTo(vp);
                var vpRect = vp.get(0).getBoundingClientRect();
                hl.css({ left: 6, right: 6, height: slotH, top: (vpRect.height/2 - slotH/2) });
            }
        } else {
            vp.append('<div class="wco-pointer h" aria-hidden="true"></div>');
            var slotW = estimateSlotSize(vp, 'horizontal');
            if (!vp.find('.wco-enh-center-highlight').length && slotW){
                var hl2 = $('<div class="wco-enh-center-highlight"></div>').appendTo(vp);
                var vpRect2 = vp.get(0).getBoundingClientRect();
                hl2.css({ top: 6, bottom: 6, width: slotW, left: (vpRect2.width/2 - slotW/2) });
            }
        }
    }

    function estimateSlotSize(vp, orient){
        var sample = vp.find('.wco-reel-track > *:first, .wco-spinner > *:first, [data-wco-track] > *:first');
        if (!sample.length) return null;
        var rect = sample.get(0).getBoundingClientRect();
        return orient === 'vertical' ? rect.height : rect.width;
    }

    function findMatchingIndex_v9(nodes, prize){
        var wanted = (prize && (prize.label || prize.prize_label || prize.name)) || '';
        var wantedLower = String(wanted).toLowerCase().trim();
        var prizeId = (prize && (prize.product_id || prize.coupon_id || prize.id || prize.prize_id));
        var idx = -1;
        for (var i=nodes.length-1; i>=0; i--){
            var $el = $(nodes[i]);
            var id  = ($el.data('id') || $el.attr('data-id') || '').toString();
            var lab = extractLabelFromItem(nodes[i]).toLowerCase().trim();
            if (wantedLower && lab === wantedLower){ idx = i; break; }
            if (prizeId && id && String(prizeId) === String(id)){ idx = i; break; }
        }
        return idx;
    }

    function animateGhostToIndex(ctx, targetIndex, done){
        var vp = ctx.viewport, ghost = ctx.ghostTrack, nodes = ctx.nodes, orient = ctx.orientation;
        if (targetIndex < 0) targetIndex = Math.floor(nodes.length/2);

        var target = $(nodes[targetIndex]).get(0);
        var rect = target.getBoundingClientRect();
        var vpRect = vp.get(0).getBoundingClientRect();

        var stopX = 0, stopY = 0;
        if (orient === 'vertical'){
            // Align target's center to viewport center Y
            var slotH = rect.height || 64;
            var targetTop = target.offsetTop; // within ghost
            var centerOffset = (vpRect.height/2) - (slotH/2);
            stopY = -(targetTop - centerOffset);
        } else {
            var slotW = rect.width || 64;
            var targetLeft = target.offsetLeft;
            var centerOffsetX = (vpRect.width/2) - (slotW/2);
            stopX = -(targetLeft - centerOffsetX);
        }

        // Apply transition
        ghost.css('transition', 'transform 4s cubic-bezier(.17,.67,.83,.67)');
        // Force layout
        ghost.get(0).offsetHeight;
        var transform = orient === 'vertical' ? 'translate(' + 0 + 'px,' + stopY + 'px)' : 'translate(' + stopX + 'px,' + 0 + 'px)';
        ghost.css('transform', transform);

        var handled = false;
        ghost.one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function(){
            if (handled) return;
            handled = true;
            if (typeof done === 'function') done();
        });
        setTimeout(function(){ if (!handled){ handled = true; if (typeof done === 'function') done(); } }, 4500);
    }

    function cleanupGhost(ctx){
        if (!ctx) return;
        ctx.viewport.removeClass('wco-enh-ghost-active');
        ctx.viewport.find('.wco-enh-center-highlight').remove();
        ctx.ghostWrap.remove();
    }

    function spinWithGhostOverlay_v9(prize, payload, done){
        // Remove previous overlay if any
        $('.wco-enh-ghost-wrap').remove();
        $('.wco-widget .wco-pointer').remove();
        var ctx = buildGhostOverlay(prize);
        if (!ctx){ if (typeof done === 'function') done(); return; }
        var index = findMatchingIndex_v9(ctx.nodes, prize);
        animateGhostToIndex(ctx, index, function(){
            if (typeof done === 'function') done();
            setTimeout(function(){ cleanupGhost(ctx); }, 300); // let user see final stop
        });
    }


    // === v8 Enhancements: reset, alignment, accurate stop ===
    function getViewportForTrack(track){
        var vp = track.closest('.wco-reel-viewport');
        if (!vp.length) vp = track.parent();
        return vp;
    }

    function ensureCenterGuide(){
        var wrap = $('.wco-widget .wco-reel-viewport, .wco-widget .wco-reel-wrap, .wco-widget .wco-spinner-container').first();
        if (wrap.length && !wrap.find('.wco-center-guide').length){
            wrap.append('<div class="wco-center-guide" aria-hidden="true"></div>');
        }
    }

    function resetSpinState(){
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-widget .wco-spinner');
        if (!track.length) return;
        // Clear transition and transform
        track.css('transition', 'none');
        track.css('transform', 'translateY(0)');
        // Clear flag so next ajaxSuccess handles new spin
        window.WCO_ENH_spinHandled = false;
        // Force reflow to apply reset
        track.get(0).offsetHeight;
    }

    // Strengthen label extraction from a reel item
    function extractLabelFromItem(el){
        var $el = $(el);
        var lab = ($el.attr('data-label') || $el.data('label') || '').toString().trim();
        if (!lab) lab = ($el.attr('data-name') || $el.data('name') || '').toString().trim();
        if (!lab) lab = ($el.text() || '').toString().trim();
        if (!lab){
            var img = $el.find('img').first();
            if (img.length){
                lab = (img.attr('alt') || img.attr('title') || '').toString().trim();
            }
        }
        return lab;
    }

    function rebuildTrackForSpin_v8(){
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-widget .wco-spinner');
        if (!track.length) return null;

        // Collect items and filter out "nothing"
        var rawItems = track.children().toArray();
        var filtered = rawItems.filter(function(el){
            var lab = extractLabelFromItem(el);
            return lab && !/nothing/i.test(lab);
        });
        if (!filtered.length) filtered = rawItems; // fallback if labels not present

        var REPEATS = 5;
        var clones = [];
        track.empty();
        for (var r=0; r<REPEATS; r++){
            filtered.forEach(function(el){
                var $c = $(el).clone(true, true);
                clones.push($c);
                track.append($c);
            });
        }

        return { track: track, items: clones.map(function($c){ return $c.get(0); }) };
    }

    function findMatchingIndex_v8(items, prize){
        var wanted = (prize && (prize.label || prize.prize_label || prize.name)) || '';
        var wantedLower = String(wanted).toLowerCase().trim();
        var prizeId = (prize && (prize.product_id || prize.coupon_id || prize.id || prize.prize_id));
        var idx = -1;

        for (var i=items.length-1; i>=0; i--){
            var $el = $(items[i]);
            var id  = ($el.data('id') || $el.attr('data-id') || '').toString();
            var lab = extractLabelFromItem(items[i]).toLowerCase().trim();
            if (wantedLower && lab === wantedLower){ idx = i; break; }
            if (prizeId && id && String(prizeId) === String(id)){ idx = i; break; }
        }
        return idx;
    }

    function spinToServerPrize_v8(prize, payload, done){
        var built = rebuildTrackForSpin_v8();
        if (!built) { if (typeof done === 'function') done(); return; }
        ensurePointer();
        ensureCenterGuide();

        var track = built.track;
        var items = built.items;
        if (!items.length) { if (typeof done === 'function') done(); return; }

        // Reset transform before measuring
        track.css('transition', 'none').css('transform', 'translateY(0)');
        track.get(0).offsetHeight;

        var targetIndex = findMatchingIndex_v8(items, prize);
        if (targetIndex < 0) targetIndex = Math.floor(items.length/2);

        var $target = $(items[targetIndex]);
        var vp = getViewportForTrack(track);
        var slotH = $target.outerHeight() || 64;
        var targetTop = $target.get(0).offsetTop; // relative to track
        var vpH = vp.innerHeight() || (slotH * 3);
        // Align target center to viewport center
        var centerOffset = (vpH/2) - (slotH/2);
        var stopY = -(targetTop - centerOffset);

        // Animate
        track.css('transition', 'transform 4s cubic-bezier(.17,.67,.83,.67)');
        track.get(0).offsetHeight; // reflow
        track.css('transform', 'translateY(' + stopY + 'px)');

        var handled = false;
        track.one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function(){
            if (handled) return;
            handled = true;
            if (typeof done === 'function') done();
        });
        setTimeout(function(){ if (!handled && typeof done === 'function'){ handled = true; done(); } }, 4500);
    }


    // === Spinner Sync with Server Prize (v7) ===
    function ensurePointer(){
        var wrap = $('.wco-widget .wco-reel-wrap, .wco-widget .wco-spinner-container, .wco-widget .wco-reel-viewport').first();
        if (wrap.length && !wrap.find('.wco-pointer').length){
            wrap.append('<div class="wco-pointer" aria-hidden="true"></div>');
        }
    }

    function rebuildTrackForSpin(){
        // Find the track element the plugin uses
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-widget .wco-spinner');
        if (!track.length) return null;

        // Collect non-empty, non-"nothing" items
        var rawItems = track.children().toArray();
        var filtered = rawItems.filter(function(el){
            var t = ($(el).text() || $(el).attr('data-label') || '').trim();
            return t && !/nothing/i.test(t);
        });
        if (!filtered.length) filtered = rawItems; // fallback if everything filtered

        // Hard-code repeat count
        var REPEATS = 5;
        var clones = [];
        track.empty();
        for (var r=0; r<REPEATS; r++){
            filtered.forEach(function(el){
                var $c = $(el).clone(true, true);
                clones.push($c);
                track.append($c);
            });
        }
        return { track: track, items: clones.map(function($c){ return $c.get(0); }) };
    }

    function findMatchingIndex(items, prize){
        // Try by data attributes first
        var wanted = (prize && (prize.label || prize.prize_label || prize.name)) || '';
        var wantedLower = String(wanted).toLowerCase();

        var idx = -1;
        for (var i=items.length-1; i>=0; i--){
            var $el = $(items[i]);
            var id  = ($el.data('id') || $el.attr('data-id') || '').toString();
            var lab = ($el.attr('data-label') || $el.text() || '').toString();
            if (lab && lab.toLowerCase().trim() === wantedLower.trim()){
                idx = i; break;
            }
            // if backend provides product_id/coupon_id we can match data-id
            var prizeId = (prize && (prize.product_id || prize.coupon_id || prize.id));
            if (prizeId && id && String(prizeId) === String(id)) { idx = i; break; }
        }
        return idx;
    }

    function spinToServerPrize(prize, payload, done){
        var built = rebuildTrackForSpin();
        if (!built) { if (typeof done === 'function') done(); return; }
        ensurePointer();

        var track = built.track;
        var items = built.items;
        if (!items.length) { if (typeof done === 'function') done(); return; }

        var targetIndex = findMatchingIndex(items, prize);
        if (targetIndex < 0) {
            // If we couldn't find, just pick the last visible slot to avoid blanks
            targetIndex = Math.max(0, items.length - 3);
        }

        // Compute slot height and target offset
        var $target = $(items[targetIndex]);
        var slotH = $target.outerHeight() || 64; // fallback height
        var stopY = -(targetIndex * slotH);

        // Animate reel to target
        track.css('transition', 'transform 4s cubic-bezier(.17,.67,.83,.67)');
        // Force layout
        track.get(0).offsetHeight;
        track.css('transform', 'translateY(' + stopY + 'px)');

        var handled = false;
        track.one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function(){
            if (handled) return;
            handled = true;
            if (typeof done === 'function') done();
        });

        // Safety timeout in case no event fires
        setTimeout(function(){ if (!handled && typeof done === 'function') { handled = true; done(); } }, 4500);
    }


    // === Pointer & Prize Track Enhancements ===
    function addPointer(){
        // Try common wrappers
        var wrap = $('.wco-widget .wco-reel-wrap, .wco-widget .wco-spinner-container').first();
        if (wrap.length && !wrap.find('.wco-pointer').length){
            wrap.append('<div class="wco-pointer" aria-hidden="true"></div>');
        } else if (!$('.wco-widget .wco-pointer').length){
            $('.wco-widget').first().append('<div class="wco-pointer" aria-hidden="true"></div>');
        }
    }
    function repeatPrizes(){
        // Duplicate prize items to avoid gaps/landing on "nothing"
        var track = $('.wco-widget .wco-reel-track');
        if (!track.length) track = $('.wco-spinner');
        if (!track.length) return;
        var items = track.children().filter(function(){
            var t = ($(this).text() || '').trim();
            return !t || !/nothing/i.test(t); // skip items labeled "nothing"
        });
        if (!items.length) items = track.children();
        if (track.children().length < 24 && items.length){
            var target = 36;
            var clones = [];
            while (track.children().length + clones.length < target){
                items.each(function(){
                    clones.push($(this).clone(true, true));
                });
            }
            clones.forEach(function($c){ track.append($c); });
        }
    }
    $(function(){
        addPointer();
        repeatPrizes();
    });

    // === Redirects after a win ===
    function safeRedirectForPrize(prize, payload){
        try{
            var type = (prize && (prize.type || prize.prize_type || prize.category)) || '';
            type = String(type).toLowerCase();
            var redirectUrl = null;

            // Prefer explicit redirect from server
            if (payload && payload.redirect){ redirectUrl = payload.redirect; }

            // Voucher / coupon → rewards
            if (!redirectUrl && (type === 'voucher' || type === 'coupon')){
                redirectUrl = (typeof WCO_ENH !== 'undefined' && WCO_ENH.rewards_url) ? WCO_ENH.rewards_url : '/my-account/rewards/';
            }

            // Product → view order
            var oid = (payload && (payload.order_id || (payload.prize && payload.prize.order_id))) || null;
            if (!redirectUrl && (type === 'product' || type === 'physical' || type === 'item')){
                if (oid && typeof WCO_ENH !== 'undefined' && WCO_ENH.view_order_base){
                    redirectUrl = WCO_ENH.view_order_base.replace(/\/$/, '') + '/' + oid + '/';
                } else if (typeof WCO_ENH !== 'undefined' && WCO_ENH.orders_url){
                    redirectUrl = WCO_ENH.orders_url;
                }
            }

            if (redirectUrl){
                setTimeout(function(){ window.location.href = redirectUrl; }, 1200);
            }
        }catch(e){ /* no-op */ }
    }


    // Modal helpers
    function ensureModal(){
        if ($('#wco-win-modal').length) return;
        $('body').append('<div id="wco-win-modal"><div class="wco-modal-content"><span class="wco-close">&times;</span><h2 class="wco-win-title"></h2><img class="wco-win-img" alt=""/><a class="wco-win-link" target="_blank" rel="noopener">View item</a></div></div>');
        $(document).on('click', '#wco-win-modal, #wco-win-modal .wco-close', function(e){
            if (e.target.id === 'wco-win-modal' || $(e.target).is('.wco-close')) $('#wco-win-modal').fadeOut(120);
        });
    }
    function showWinModal(data){
        if (!WCO_ENH || !WCO_ENH.win_popup) return;
        ensureModal();
        var name = data && (data.prize_name || data.label || (data.prize && data.prize.label)) || 'a prize';
        var img  = data && (data.prize_img || (data.prize && data.prize.meta && data.prize.meta.image)) || '';
        var url  = data && (data.prize_url || (data.prize && data.prize.meta && (data.prize.meta.product_url || data.prize.meta.coupon_url))) || '#';
        $('#wco-win-modal .wco-win-title').text('🎉 You won: ' + name);
        if (img) { $('#wco-win-modal .wco-win-img').attr('src', img).show(); } else { $('#wco-win-modal .wco-win-img').hide(); }
        $('#wco-win-modal .wco-win-link').attr('href', url);
        $('#wco-win-modal').fadeIn(120);
        setTimeout(function(){ $('#wco-win-modal').fadeOut(200); }, 7000);
    }

    // Confetti
    function confetti(){
        if (!WCO_ENH || !WCO_ENH.confetti) return;
        for (var i=0;i<60;i++){
            (function(){
                var d = $('<div class="wco-confetti"></div>').appendTo('body');
                var left = Math.random()*window.innerWidth;
                var duration = 2 + Math.random()*1.5;
                var rotate = Math.floor(Math.random()*360);
                d.css({left:left+'px', background:'hsl('+Math.floor(Math.random()*360)+',80%,60%)', transform:'rotate('+rotate+'deg)'});
                d.animate({top: window.innerHeight+20, left: left + (Math.random()*80 - 40)}, duration*1000, 'linear', function(){ d.remove(); });
            })();
        }
    }

    // Public preview hook for admin
    window.WCO_ENH_previewWin = function(){
        showWinModal({ prize_name: 'Golden Widget', prize_url: '#', prize_img: '' });
        confetti();
    };

    // Detect real wins from AJAX
    $(document).ajaxSuccess(function(event, xhr, settings){
        try {
            var isWco = (settings && settings.url && (String(settings.url).indexOf('wco/v1/open')!==-1 || String(settings.url).indexOf('wco_open_case')!==-1));
            if (!isWco) return;
            var data = xhr.responseJSON || JSON.parse(xhr.responseText);
            if (!data) return;
            var prize = data.prize || data.data || data.result || data;
            var label = (prize && (prize.label || prize.prize_label || prize.name)) || null;
            var type  = (prize && (prize.type  || prize.prize_type)) || null;
            if (label && type && type !== 'nothing') {
                // v7: synchronize spinner with server-chosen prize, delay modal until spin ends
                if (!window.WCO_ENH_spinHandled) {
                    window.WCO_ENH_spinHandled = true;
                    spinHorizontal_v10(prize, data, function(){
                        showWinModal({ prize_name: label, prize: prize });
                        confetti();
                        $(document).trigger('wco:caseWon', [{ prize_name: label, prize: prize }]);
                        safeRedirectForPrize(prize, data);
                    });
                    return;
                }
                safeRedirectForPrize(prize, data);
                showWinModal({ prize_name: label, prize: prize });
                confetti();
                $(document).trigger('wco:caseWon', [{ prize_name: label, prize: prize }]);
            }
        } catch(e){ /* ignore */ }
    });

    // Enhance spinner button feedback
    $(document).on('click', '.wco-open-btn', function(){
        if (!WCO_ENH || !WCO_ENH.enhanced_spinner) return;
        $(this).addClass('loading');
        resetSpinState();
        var btn = $(this);
        setTimeout(function(){ btn.removeClass('loading'); }, 2600);
    });
})(jQuery);
