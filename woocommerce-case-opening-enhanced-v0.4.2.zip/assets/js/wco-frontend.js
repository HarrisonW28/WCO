(function($){
    function spinToPrize($widget, labelText){
        var $track = $widget.find('.wco-reel-track');
        var $items = $track.find('.wco-reel-item');
        var targetIndex = -1;
        $items.each(function(i){
            if ($(this).text() === labelText && targetIndex === -1) targetIndex = i;
        });
        if (targetIndex === -1) targetIndex = Math.floor(Math.random()*$items.length);

        var itemWidth = $items.outerWidth(true);
        var loops = 3; // full loops before stop
        var offset = (loops * $items.length + targetIndex) * itemWidth;
        $track.css({transition: 'transform 2.2s cubic-bezier(.17,.67,.35,1.3)', transform: 'translateX(' + (-offset) + 'px)'});
        setTimeout(function(){ $track.css({transition: 'none'}); }, 2300);
    }

    $(document).on('click', '.wco-open-btn', function(e){
        e.preventDefault();
        var $w = $(this).closest('.wco-widget');
        var caseId = $w.data('case') || 0;
        var $btn = $(this);
        var $res = $w.find('.wco-result');
        var $keys = $w.find('.wco-keys-count');

        $btn.prop('disabled', true);
        $res.removeClass('wco-win').text('Spinning...');
        $w.addClass('wco-spinning');

        $.ajax({
            url: WCO.rest.url,
            method: 'POST',
            headers: { 'X-WP-Nonce': WCO.rest.nonce },
            data: { case_id: caseId },
        }).done(function(resp){
            if (resp && resp.result) {
                spinToPrize($w, resp.result.label);
                setTimeout(function(){
                    $res.addClass('wco-win').html('You won: <strong>' + resp.result.label + '</strong>');
                    $keys.text(resp.keys_remaining);
                }, 2300);
            } else if (resp && resp.error) {
                $res.text(resp.error);
            } else {
                $res.text('Unknown response');
            }
        }).fail(function(xhr){
            var msg = 'Error opening case';
            if (xhr.responseJSON && xhr.responseJSON.error) msg = xhr.responseJSON.error;
            $res.text(msg);
        }).always(function(){
            setTimeout(function(){
                $btn.prop('disabled', false);
                $w.removeClass('wco-spinning');
            }, 2300);
        });
    });
})(jQuery);
