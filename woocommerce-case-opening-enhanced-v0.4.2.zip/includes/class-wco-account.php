<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCO_Account {
    private static $instance = null;
    const ENDPOINT = 'rewards';

    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', [ $this, 'add_endpoint' ] );
        add_filter( 'woocommerce_account_menu_items', [ $this, 'add_menu_item' ], 99 );
        add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', [ $this, 'endpoint_content' ] );
    }

    public function add_endpoint() {
        add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
    }

    public function add_menu_item( $items ) {
        // insert near the end
        $new = [];
        foreach ( $items as $key => $label ) {
            $new[$key] = $label;
            if ( $key === 'customer-logout' ) {
                $new[self::ENDPOINT] = __( 'Rewards', 'woocommerce-case-opening' );
            }
        }
        if ( ! isset( $new[self::ENDPOINT] ) ) {
            $new[self::ENDPOINT] = __( 'Rewards', 'woocommerce-case-opening' );
        }
        return $new;
    }

    public function endpoint_content() {
        if ( ! is_user_logged_in() ) { echo '<p>You must be logged in.</p>'; return; }
        $user_id = get_current_user_id();
        $keys = intval( get_user_meta( $user_id, WCO_Core::USER_KEYS_META, true ) );
        echo '<h3>Your Rewards</h3>';
        echo '<p><strong>Keys:</strong> ' . esc_html( $keys ) . '</p>';

        global $wpdb;
        $table = $wpdb->prefix . 'wco_wins';
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT 200", $user_id ), ARRAY_A );
        if ( $rows ) {
            echo '<h4>Recent Wins</h4>';
            echo '<table class="shop_table shop_table_responsive my_account_orders">';
            echo '<thead><tr><th>Date</th><th>Prize</th><th>Type</th><th>Status</th><th>Order</th></tr></thead><tbody>';
            foreach ( $rows as $r ) {
                $status = ! empty( $r['status'] ) ? esc_html( $r['status'] ) : '—';
                $order_html = '—';
                if ( ! empty( $r['order_id'] ) ) {
                    $order = wc_get_order( intval( $r['order_id'] ) );
                    if ( $order ) {
                        $order_html = '<a href="'. esc_url( $order->get_view_order_url() ) .'">#'. esc_html( $order->get_id() ) .'</a>';
                    }
                }
                echo '<tr>';
                echo '<td>'. esc_html( $r['created_at'] ) .'</td>';
                echo '<td>'. esc_html( $r['prize_label'] ) .'</td>';
                echo '<td>'. esc_html( $r['prize_type'] ) .'</td>';
                echo '<td>'. $status .'</td>';
                echo '<td>'. $order_html .'</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<h4>Recent Wins</h4><p>No rewards yet.</p>';
        }

        // --- ADDED: Coupons recorded in user meta (_wco_rewards) ---
        $rewards = get_user_meta( $user_id, '_wco_rewards', true );
        if ( ! is_array( $rewards ) ) { $rewards = []; }

        echo '<h4>Your Coupons</h4>';
        if ( empty( $rewards ) ) {
            echo '<p>No coupons yet.</p>';
            return;
        }

        echo '<table class="shop_table shop_table_responsive my_account_orders"><thead>';
        echo '<tr><th>Coupon Code</th><th>Value</th><th>Expiry</th><th>Status</th></tr>';
        echo '</thead><tbody>';

        foreach ( $rewards as $entry ) {
            $coupon_id   = intval( $entry['coupon_id'] ?? 0 );
            $coupon_code = sanitize_text_field( $entry['coupon_code'] ?? '' );
            $amount      = $entry['amount'] ?? '';
            $type        = sanitize_text_field( $entry['type'] ?? '' );
            $expiry_ts   = isset($entry['expiry']) ? intval( $entry['expiry'] ) : 0;

            $value_label = '';
            if ( $type === 'percent' ) {
                $value_label = esc_html( $amount ) . '%';
            } else {
                $value_label = function_exists('wc_price') ? wc_price( floatval( $amount ) ) : esc_html( $amount );
            }

            $expiry_label = $expiry_ts ? date_i18n( get_option( 'date_format' ), $expiry_ts ) : '—';

            // Determine status (Available / Used / Expired)
            $status_label = 'Available';
            $now = time();
            if ( $expiry_ts && $expiry_ts < $now ) {
                $status_label = 'Expired';
            } else {
                if ( $coupon_id > 0 && class_exists('WC_Coupon') ) {
                    try {
                        $usage_count = intval( get_post_meta( $coupon_id, 'usage_count', true ) );
                        $usage_limit = intval( get_post_meta( $coupon_id, 'usage_limit', true ) );
                        if ( $usage_limit > 0 && $usage_count >= $usage_limit ) {
                            $status_label = 'Used';
                        }
                    } catch ( \Throwable $e ) {
                        // ignore
                    }
                }
            }

            echo '<tr>';
            echo '<td><code style="font-size:14px;">' . esc_html( $coupon_code ) . '</code></td>';
            echo '<td>' . wp_kses_post( $value_label ) . '</td>';
            echo '<td>' . esc_html( $expiry_label ) . '</td>';
            echo '<td>' . esc_html( $status_label ) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }
}
