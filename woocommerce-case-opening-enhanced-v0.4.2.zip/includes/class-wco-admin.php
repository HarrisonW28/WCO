<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCO_Admin {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'menu' ] );
        add_action( 'admin_post_wco_mark_fulfilled', [ $this, 'mark_fulfilled' ] );
        add_action( 'admin_post_wco_resend_email', [ $this, 'resend_email' ] );
    }

    public function menu() {
        add_menu_page( 'Case Opening', 'Case Opening', 'manage_woocommerce', 'wco-dashboard', [ $this, 'dashboard_page' ], 'dashicons-tickets', 56 );
        add_submenu_page( 'wco-dashboard', 'Wins & Fulfillment', 'Wins & Fulfillment', 'manage_woocommerce', 'wco-wins', [ $this, 'wins_page' ] );
        add_submenu_page( 'wco-dashboard', 'Key Grants', 'Key Grants', 'manage_woocommerce', 'wco-key-grants', [ $this, 'key_grants_page' ] );
        add_submenu_page( 'wco-dashboard', 'How Keys Work', 'Keys Setup', 'manage_woocommerce', 'wco-keys', [ $this, 'keys_page' ] );
    }

    public function dashboard_page() {
        echo '<div class="wrap"><h1>WooCommerce Case Opening</h1><p>Use the submenu to manage wins and keys. Create cases under the "Cases" post type.</p></div>';
    }

    public function keys_page() {
        echo '<div class="wrap"><h1>Keys Setup</h1><p>Qualifying amount is set in <em>Settings → WCO</em>. Optionally, add a custom field <code>_wco_keys_per_purchase</code> on a product to grant extra keys per item.</p></div>';
    }

    public function wins_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'wco_wins';
        $rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 500", ARRAY_A );
        $admin_url = admin_url('admin-post.php');
        echo '<div class="wrap"><h1>Wins & Fulfillment</h1>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Date</th><th>User</th><th>Case</th><th>Prize</th><th>Type</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        if ( $rows ) {
            foreach ( $rows as $r ) {
                $user = get_userdata( intval($r['user_id']) );
                $user_label = $user ? esc_html( $user->user_login . ' (' . $user->user_email . ')' ) : 'User #' . intval($r['user_id']);
                $case_title = $r['case_id'] ? get_the_title( intval($r['case_id']) ) : '—';
                $status = intval($r['fulfilled']) ? '<span style="color:green;font-weight:bold">Fulfilled</span>' : '<span style="color:#d63638;font-weight:bold">Pending</span>';
                $order_html = $r['order_id'] ? '<a href="'. esc_url( admin_url('post.php?post='.$r['order_id'].'&action=edit') ) .'">#'. intval($r['order_id']) .'</a>' : '—';
                $actions = [];
                if ( ! intval($r['fulfilled']) ) {
                    $actions[] = '<a class="button button-small" href="'. esc_url( wp_nonce_url( "{$admin_url}?action=wco_mark_fulfilled&id={$r['id']}", 'wco_mark_fulfilled_'.$r['id'] ) ) .'">Mark Fulfilled</a>';
                }
                $actions[] = '<a class="button button-small" href="'. esc_url( wp_nonce_url( "{$admin_url}?action=wco_resend_email&id={$r['id']}", 'wco_resend_email_'.$r['id'] ) ) .'">Resend Email</a>';
                echo '<tr>';
                echo '<td>'. intval($r['id']) .'</td>';
                echo '<td>'. esc_html($r['created_at']) .'</td>';
                echo '<td>'. $user_label .'</td>';
                echo '<td>'. esc_html($case_title) .'</td>';
                echo '<td>'. esc_html($r['prize_label']) .'</td>';
                echo '<td>'. esc_html($r['prize_type']) .'</td>';
                echo '<td>'. $order_html .'</td>';
                echo '<td>'. $status .'</td>';
                echo '<td>'. implode(' ', $actions) .'</td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="9">No wins yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function key_grants_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'wco_key_grants';
        $rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 500", ARRAY_A );
        echo '<div class="wrap"><h1>Key Grants</h1>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Date</th><th>User</th><th>Order</th><th>Keys</th><th>Reason</th></tr></thead><tbody>';
        if ( $rows ) {
            foreach ( $rows as $r ) {
                $user = get_userdata( intval($r['user_id']) );
                $user_label = $user ? esc_html( $user->user_login . ' (' . $user->user_email . ')' ) : 'User #' . intval($r['user_id']);
                $order_html = $r['order_id'] ? '<a href="'. esc_url( admin_url('post.php?post='.$r['order_id'].'&action=edit') ) .'">#'. intval($r['order_id']) .'</a>' : '—';
                echo '<tr>';
                echo '<td>'. intval($r['id']) .'</td>';
                echo '<td>'. esc_html($r['created_at']) .'</td>';
                echo '<td>'. $user_label .'</td>';
                echo '<td>'. $order_html .'</td>';
                echo '<td>'. intval($r['keys_awarded']) .'</td>';
                echo '<td>'. esc_html($r['reason']) .'</td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="6">No key grants yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function mark_fulfilled() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'No access' );
        $id = intval( $_GET['id'] ?? 0 );
        check_admin_referer( 'wco_mark_fulfilled_' . $id );
        global $wpdb;
        $table = $wpdb->prefix . 'wco_wins';
        $wpdb->update( $table, [ 'fulfilled' => 1 ], [ 'id' => $id ] );
        wp_safe_redirect( admin_url( 'admin.php?page=wco-wins' ) ); exit;
    }

    public function resend_email() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'No access' );
        $id = intval( $_GET['id'] ?? 0 );
        check_admin_referer( 'wco_resend_email_' . $id );
        global $wpdb;
        $table = $wpdb->prefix . 'wco_wins';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A );
        if ( $row ) {
            $user = get_userdata( intval($row['user_id']) );
            if ( $user ) {
                wp_mail( $user->user_email, 'Your prize details', 'Prize: ' . $row['prize_label'] . ' (Type: ' . $row['prize_type'] . ')' );
            }
        }
        wp_safe_redirect( admin_url( 'admin.php?page=wco-wins' ) ); exit;
    }
}
