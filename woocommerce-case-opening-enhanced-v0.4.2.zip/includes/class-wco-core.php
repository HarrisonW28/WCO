<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCO_Core {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    const USER_KEYS_META = '_wco_keys';
    const CASE_POST_TYPE = 'wco_case';
    const PRIZES_META    = '_wco_prizes_json'; // JSON
    const SETTINGS_OPTION = 'wco_settings';    // array of plugin settings

    private function __construct() {
        add_action( 'init', [ $this, 'register_post_types' ] );
        add_action( 'admin_menu', [ $this, 'register_settings_page' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_metaboxes' ] );
        add_action( 'save_post_' . self::CASE_POST_TYPE, [ $this, 'save_prizes_metabox' ] );

        // Keys are granted when order hits configured status
        add_action( 'woocommerce_order_status_changed', [ $this, 'maybe_grant_keys' ], 10, 4 );

        // REST for opening a case
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

        // Shortcodes
        add_shortcode( 'wco_open_case', [ $this, 'shortcode_open_case' ] );
        add_shortcode( 'wco_odds',      [ $this, 'shortcode_odds' ] );

        // Assets
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    public function register_post_types() {
        register_post_type( self::CASE_POST_TYPE, [
            'label' => __( 'Cases', 'woocommerce-case-opening' ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'supports' => [ 'title', 'editor' ],
            'menu_icon' => 'dashicons-archive'
        ] );
    }

    public function register_metaboxes() {
        add_meta_box(
            'wco_prizes_builder',
            __( 'Prize Pool', 'woocommerce-case-opening' ),
            [ $this, 'metabox_prizes_builder_html' ],
            self::CASE_POST_TYPE,
            'normal',
            'default'
        );
    }

    public function metabox_prizes_builder_html( $post ) {
        $json   = get_post_meta( $post->ID, self::PRIZES_META, true );
        $prizes = json_decode( $json, true );
        if ( ! is_array( $prizes ) ) {
            $prizes = [
                ['label'=>'£5 Store Credit','type'=>'coupon_fixed_cart','weight'=>70,'value'=>5],
                ['label'=>'£10 Store Credit','type'=>'coupon_fixed_cart','weight'=>25,'value'=>10],
                ['label'=>'iPhone 15','type'=>'product','weight'=>5,'product_id'=>0]
            ];
        }
        wp_nonce_field( 'wco_save_prizes', 'wco_prizes_nonce' );
        echo '<div id="wco-prize-builder" class="wco-builder" data-field="'.esc_attr(self::PRIZES_META).'"></div>';
        echo '<input type="hidden" id="wco_prizes_json" name="wco_prizes_json" value="'. esc_attr( wp_json_encode( $prizes ) ) .'"/>';
        echo '<p class="description">Add prizes. Odds are based on weights. Coupons auto-generate one-time coupons; Products create zero-total orders.</p>';
    }

    public function save_prizes_metabox( $post_id ) {
        if ( ! isset( $_POST['wco_prizes_nonce'] ) || ! wp_verify_nonce( $_POST['wco_prizes_nonce'], 'wco_save_prizes' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        $json = wp_unslash( $_POST['wco_prizes_json'] ?? '' );
        update_post_meta( $post_id, self::PRIZES_META, $json );
    }

    public function register_settings_page() {
        add_options_page(
            __( 'WooCommerce Case Opening', 'woocommerce-case-opening' ),
            __( 'WCO', 'woocommerce-case-opening' ),
            'manage_options',
            'wco-settings',
            [ $this, 'settings_page_html' ]
        );
        register_setting( 'wco_settings_group', self::SETTINGS_OPTION );
    }

    public function settings_page_html() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $defaults = [
            'default_case_id' => 0,
            'order_status_trigger' => 'completed',
            'log_odds_public' => 1,
            'qualifying_amount' => 10, // £10 default (every £10 = 1 key)
            'enable_key_sale' => 0,
            'key_pack_product' => 0,
            'keys_per_pack' => 1,
            'wallet_mode' => 0,
            'age_gate' => 0,
            'geo_restrict' => ''
        ];
            // Additive defaults for UI enhancements (enabled by default). We avoid editing the literal array.
            $defaults = array_merge( $defaults, [
                'enhanced_spinner' => 1,
                'win_popup'        => 1,
                'confetti'         => 1,
            ] );

        $opt = get_option( self::SETTINGS_OPTION, $defaults );
        $cases = get_posts([ 'post_type' => self::CASE_POST_TYPE, 'numberposts' => -1 ]);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('WooCommerce Case Opening - Settings', 'woocommerce-case-opening'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wco_settings_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Default Case</th>
                        <td>
                            <select name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[default_case_id]">
                                <option value="0">— Select a Case —</option>
                                <?php foreach ( $cases as $c ): ?>
                                <option value="<?php echo esc_attr( $c->ID ); ?>" <?php selected( $opt['default_case_id'], $c->ID ); ?>>
                                    <?php echo esc_html( $c->post_title ); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Order Status Trigger</th>
                        <td>
                            <select name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[order_status_trigger]">
                                <?php foreach ( [ 'completed', 'processing' ] as $st ): ?>
                                <option value="<?php echo esc_attr($st); ?>" <?php selected( $opt['order_status_trigger'], $st ); ?>><?php echo esc_html( ucfirst($st) ); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">When an order reaches this status, keys are granted based on qualifying amount (and optionally key packs).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Qualifying Purchase Amount (GBP)</th>
                        <td>
                            <input type="number" step="0.01" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[qualifying_amount]" value="<?php echo esc_attr( $opt['qualifying_amount'] ); ?>" />
                            <p class="description">Default £10. Keys awarded = floor(order_total / qualifying_amount).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Enable Key Sale</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[enable_key_sale]" value="1" <?php checked( intval($opt['enable_key_sale']), 1 ); ?>> Allow selling key packs as WooCommerce products</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Key Pack Product</th>
                        <td>
                            <input type="number" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[key_pack_product]" value="<?php echo esc_attr( $opt['key_pack_product'] ); ?>" />
                            <p class="description">Product ID. If purchased (and sale enabled), buyer receives "Keys per Pack" × quantity.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Keys per Pack</th>
                        <td><input type="number" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[keys_per_pack]" value="<?php echo esc_attr( $opt['keys_per_pack'] ); ?>" min="1" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Wallet Mode</th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[wallet_mode]" value="1" <?php checked( intval($opt['wallet_mode']), 1 ); ?>> Use wallet balance for credit prizes (if available)</label></td>
                    </tr>
                    <tr>
                        <th scope="row">Publish Odds</th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[log_odds_public]" value="1" <?php checked( intval($opt['log_odds_public']), 1 ); ?>> Show odds via shortcode [wco_odds]</label></td>
                    </tr>
                    <tr>
                        <th scope="row">Compliance</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[age_gate]" value="1" <?php checked( intval($opt['age_gate']), 1 ); ?>> Require 18+ confirmation</label><br/>
                            <label>Geo Restrict (ISO2 list): <input type="text" name="<?php echo esc_attr(self::SETTINGS_OPTION); ?>[geo_restrict]" value="<?php echo esc_attr( $opt['geo_restrict'] ); ?>" /></label>
                        </td>
                    </tr>
                
                <tr><th colspan="2"><h2>Enhancements</h2></th></tr>
                <tr>
                    <th scope="row">Enhanced Spinner</th>
                    <td><label><input type="checkbox" name="<?php echo self::SETTINGS_OPTION; ?>[enhanced_spinner]" value="1" <?php checked( intval($opt['enhanced_spinner'] ?? 1), 1 ); ?>> Enable smoother, responsive spinner</label></td>
                </tr>
                <tr>
                    <th scope="row">Win Popup</th>
                    <td><label><input type="checkbox" name="<?php echo self::SETTINGS_OPTION; ?>[win_popup]" value="1" <?php checked( intval($opt['win_popup'] ?? 1), 1 ); ?>> Show modal popup on win</label></td>
                </tr>
                <tr>
                    <th scope="row">Confetti</th>
                    <td><label><input type="checkbox" name="<?php echo self::SETTINGS_OPTION; ?>[confetti]" value="1" <?php checked( intval($opt['confetti'] ?? 1), 1 ); ?>> Celebrate wins with confetti</label></td>
                </tr>
                <tr>
                    <th scope="row">Preview</th>
                    <td>
                        <button type="button" class="button" id="wco-enh-preview">Preview Win Popup/Confetti</button>
                        <p class="description">Preview the enhanced UI without making a real request.</p>
                    </td>
                </tr>
</table>
                <?php submit_button(); ?>
            </form>
            <hr/>
            <p><strong>Key grants:</strong> floor(order_total / qualifying_amount) by default (e.g. £25 on £10 threshold = 2 keys). If Key Sale is enabled and a configured product is purchased, the buyer gets Keys per Pack × quantity.</p>
        </div>
        <?php
    }

    public function enqueue_assets() {
        wp_register_script( 'wco-frontend', WCO_URL . 'assets/js/wco-frontend.js', [ 'jquery' ], WCO_VERSION, true );
        wp_localize_script( 'wco-frontend', 'WCO', [
            'rest' => [
                'url' => esc_url_raw( rest_url( 'wco/v1/open' ) ),
                'nonce' => wp_create_nonce( 'wp_rest' )
            ]
        ] );
        wp_register_style( 'wco-frontend', WCO_URL . 'assets/css/wco-frontend.css', [], WCO_VERSION );
        wp_enqueue_style( 'wco-frontend' );
        wp_enqueue_script( 'wco-frontend' );
    
        // === UI Enhancements (additive) ===
        $opt = get_option( self::SETTINGS_OPTION, [] );
        $enhanced_spinner = intval( $opt['enhanced_spinner'] ?? 1 );
        $win_popup = intval( $opt['win_popup'] ?? 1 );
        $confetti = intval( $opt['confetti'] ?? 1 );
        if ( ! is_admin() && ( $enhanced_spinner || $win_popup || $confetti ) ) {
            wp_register_style( 'wco-enhancements', WCO_URL . 'assets/css/wco-enhancements.css', [], WCO_VERSION );
            wp_enqueue_style( 'wco-enhancements' );
            wp_register_script( 'wco-enhancements', WCO_URL . 'assets/js/wco-enhancements.js', [ 'jquery' ], WCO_VERSION, true );
            wp_localize_script( 'wco-enhancements', 'WCO_ENH', [
                'enhanced_spinner' => $enhanced_spinner,
                'win_popup'        => $win_popup,
                'confetti'         => $confetti,
            
                
'rewards_url'     => trailingslashit( wc_get_page_permalink( 'myaccount' ) ) . 'rewards/',
'view_order_base' => trailingslashit( wc_get_endpoint_url( 'view-order', '', wc_get_page_permalink( 'myaccount' ) ) ),
'orders_url'      => wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ),
] );
            wp_enqueue_script( 'wco-enhancements' );
        }
}

    public function enqueue_admin_assets( $hook ) {
        global $post_type;
        if ( ( 'post.php' === $hook || 'post-new.php' === $hook ) && $post_type === self::CASE_POST_TYPE ) {
            wp_enqueue_script( 'wco-admin', WCO_URL . 'assets/js/wco-admin.js', [ 'jquery' ], WCO_VERSION, true );
            wp_enqueue_style( 'wco-admin', WCO_URL . 'assets/css/wco-admin.css', [], WCO_VERSION );
        }
    
        // === Enhancements admin assets for preview button ===
        if ( isset($_GET['page']) && $_GET['page'] === 'wco-settings' ) {
            wp_register_style( 'wco-enhancements', WCO_URL . 'assets/css/wco-enhancements.css', [], WCO_VERSION );
            wp_enqueue_style( 'wco-enhancements' );
            wp_register_script( 'wco-enhancements', WCO_URL . 'assets/js/wco-enhancements.js', [ 'jquery' ], WCO_VERSION, true );
            $opt = get_option( self::SETTINGS_OPTION, [] );
            wp_localize_script( 'wco-enhancements', 'WCO_ENH', [
                'enhanced_spinner' => intval($opt['enhanced_spinner'] ?? 1),
                'win_popup'        => intval($opt['win_popup'] ?? 1),
                'confetti'         => intval($opt['confetti'] ?? 1),
            ] );
            wp_enqueue_script( 'wco-enhancements' );
            wp_register_script( 'wco-enhancements-admin', WCO_URL . 'assets/js/wco-enhancements-admin.js', [ 'jquery' ], WCO_VERSION, true );
            wp_enqueue_script( 'wco-enhancements-admin' );
        }
}

    // === Shortcodes ===
    public function shortcode_open_case( $atts ) {
        $atts = shortcode_atts( [ 'case_id' => 0 ], $atts );
        $user_id = get_current_user_id();
        if ( ! $user_id ) return '<p>You must be logged in to open a case.</p>';
        $keys = intval( get_user_meta( $user_id, self::USER_KEYS_META, true ) );
        wp_enqueue_script( 'wco-frontend' );
        wp_enqueue_style( 'wco-frontend' );

        $case_id = intval( $atts['case_id'] );
        if ( $case_id <= 0 ) {
            $opt = get_option( self::SETTINGS_OPTION, [] );
            $case_id = intval( $opt['default_case_id'] ?? 0 );
        }
        $case_title = $case_id ? get_the_title( $case_id ) : 'Case';
        $prizes = $this->get_prize_pool( $case_id );
        $labels = array_map(function($p){ return $p['label']; }, $prizes);

        ob_start(); ?>
        <div class="wco-widget" data-case="<?php echo esc_attr($case_id); ?>">
            <div class="wco-keys">Keys: <span class="wco-keys-count"><?php echo esc_html( $keys ); ?></span></div>
            <div class="wco-reel">
                <div class="wco-reel-track">
                    <?php foreach ($labels as $l): ?><div class="wco-reel-item"><?php echo esc_html($l); ?></div><?php endforeach; ?>
                    <?php foreach ($labels as $l): ?><div class="wco-reel-item"><?php echo esc_html($l); ?></div><?php endforeach; ?>
                </div>
            </div>
            <button class="wco-open-btn" <?php disabled( $keys <= 0 ); ?>>Open "<?php echo esc_html( $case_title ); ?>"</button>
            <div class="wco-result"></div>
        </div>
        <?php return ob_get_clean();
    }

    public function shortcode_odds( $atts ) {
        $atts = shortcode_atts( [ 'case_id' => 0 ], $atts );
        $case_id = intval( $atts['case_id'] );
        if ( $case_id <= 0 ) {
            $opt = get_option( self::SETTINGS_OPTION, [] );
            $case_id = intval( $opt['default_case_id'] ?? 0 );
        }
        $prizes = $this->get_prize_pool( $case_id );
        if ( empty( $prizes ) ) return '<p>No prize data.</p>';
        $total = array_sum( array_map( function($p){ return intval($p['weight'] ?? 0); }, $prizes ) );
        ob_start();
        echo '<table class="wco-odds"><thead><tr><th>Prize</th><th>Odds</th></tr></thead><tbody>';
        foreach ( $prizes as $p ) {
            $w = intval( $p['weight'] ?? 0 );
            $pct = $total > 0 ? round( ( $w / $total ) * 100, 2 ) : 0;
            echo '<tr><td>' . esc_html( $p['label'] ?? 'Prize' ) . '</td><td>' . esc_html( $pct ) . '%</td></tr>';
        }
        echo '</tbody></table>';
        return ob_get_clean();
    }

    // === REST ===
    public function register_rest_routes() {
        register_rest_route( 'wco/v1', '/open', [
            'methods'  => 'POST',
            'callback' => [ $this, 'rest_open_case' ],
            'permission_callback' => function() { return is_user_logged_in(); }
        ] );
    }

    public function rest_open_case( $request ) {
        $user_id = get_current_user_id();
        if ( ! wp_verify_nonce( $request->get_header( 'x_wp_nonce' ), 'wp_rest' ) ) {
            return new WP_REST_Response( [ 'error' => 'Invalid nonce' ], 403 );
        }
        $case_id = intval( $request->get_param( 'case_id' ) );
        if ( $case_id <= 0 ) {
            $opt = get_option( self::SETTINGS_OPTION, [] );
            $case_id = intval( $opt['default_case_id'] ?? 0 );
        }
        $keys = intval( get_user_meta( $user_id, self::USER_KEYS_META, true ) );
        if ( $keys <= 0 ) return new WP_REST_Response( [ 'error' => 'No keys' ], 400 );

        $prizes = $this->get_prize_pool( $case_id );
        if ( empty( $prizes ) ) return new WP_REST_Response( [ 'error' => 'No prize pool configured' ], 400 );

        // Decrement key first to prevent abuse
        $this->add_keys( $user_id, -1 );

        // Pick prize
        $won   = $this->weighted_pick( $prizes );

        // Award prize and capture award details (coupon code, order id, etc.)
        $award = $this->award_prize( $user_id, $case_id, $won );

        // Log win (store both prize definition + award details in prize_meta)
        $this->log_win( $user_id, $case_id, $won, $award['order_id'] ?? 0, $award );

        return new WP_REST_Response( [
            'result' => [
                'label' => $won['label'] ?? 'Prize',
                'type'  => $won['type'] ?? 'unknown',
                'meta'  => $award
            ],
            'keys_remaining' => intval( get_user_meta( $user_id, self::USER_KEYS_META, true ) )
        ], 200 );
    }

    private function get_prize_pool( $case_id ) {
        $json   = $case_id ? get_post_meta( $case_id, self::PRIZES_META, true ) : '';
        $prizes = json_decode( $json, true );
        if ( ! is_array( $prizes ) ) $prizes = [];
        $clean = [];
        foreach ( $prizes as $p ) {
            $clean[] = [
                'label' => sanitize_text_field( $p['label'] ?? 'Prize' ),
                'type'  => sanitize_text_field( $p['type'] ?? 'coupon_fixed_cart' ),
                'weight'=> intval( $p['weight'] ?? 0 ),
                'value' => isset($p['value']) ? floatval($p['value']) : null,
                'product_id' => isset($p['product_id']) ? intval($p['product_id']) : null,
                'expires_days' => isset($p['expires_days']) ? intval($p['expires_days']) : 0
            ];
        }
        return $clean;
    }

    private function weighted_pick( $prizes ) {
        $total = 0;
        foreach ( $prizes as $p ) { $total += max( 0, intval($p['weight']) ); }
        if ( $total <= 0 ) return $prizes[0];
        try { $rand = random_int(1, $total); } catch ( Exception $e ) { $rand = mt_rand(1, $total); }
        $acc = 0;
        foreach ( $prizes as $p ) {
            $acc += max( 0, intval($p['weight']) );
            if ( $rand <= $acc ) return $p;
        }
        return end( $prizes );
    }

    /**
     * Award prize to user. Returns array with award details:
     * - coupon_code, coupon_id, amount
     * - order_id, product_id
     */
    private function award_prize( $user_id, $case_id, $prize ) {
        $type = $prize['type'] ?? '';
        $user = get_userdata( $user_id );
        $user_email = $user ? $user->user_email : '';
        $result = [ 'type' => $type ];

        switch ( $type ) {
            case 'coupon_fixed_cart':
            case 'coupon_percent':
            case 'credit':
                $amount = floatval( $prize['value'] ?? $prize['amount'] ?? 0 );
                // credit alias -> fixed cart coupon for MVP
                $discount_type = $type === 'coupon_percent' ? 'percent' : 'fixed_cart';
                $code = 'WCO-' . strtoupper( wp_generate_password( 10, false, false ) );
                $coupon_id = wp_insert_post( [
                    'post_title'  => $code,
                    'post_content'=> 'WCO prize coupon',
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'post_type'   => 'shop_coupon',
                ] );
                if ( $coupon_id && ! is_wp_error( $coupon_id ) ) {
                    update_post_meta( $coupon_id, 'discount_type', $discount_type );
                    update_post_meta( $coupon_id, 'coupon_amount', $amount );
                    update_post_meta( $coupon_id, 'individual_use', 'yes' );
                    update_post_meta( $coupon_id, 'usage_limit', 1 );
                    update_post_meta( $coupon_id, 'usage_limit_per_user', 1 );
                    update_post_meta( $coupon_id, 'customer_email', $user_email );

                    $days = intval( $prize['expires_days'] ?? 0 );
                    $expires = null;
                    if ( $days > 0 ) {
                        $expires = (new DateTime('now', wp_timezone()))->modify("+{$days} days");
                        update_post_meta( $coupon_id, 'date_expires', $expires->format('U') );
                    }

                    $result['coupon_code'] = $code;
                    $result['coupon_id'] = $coupon_id;

            // Log coupon to user rewards
            $this->log_reward_to_user( $user_id, [
                'coupon_id'   => $coupon_id,
                'coupon_code' => $code,
                'amount'      => $amount,
                'type'        => $discount_type,
                'expiry'      => $expires ? intval( $expires->format( 'U' ) ) : null,
            ] );
                    $result['amount'] = $amount;

                    // send email to user
                    if ( $user_email ) {
                        $subject = 'Congratulations — you won a prize';
                        $body  = '<p>Nice one — you won <strong>' . esc_html( $prize['label'] ?? 'a prize' ) . '</strong>.</p>';
                        $body .= '<p>Your coupon code: <strong>' . esc_html( $code ) . '</strong></p>';
                        $body .= '<p>Use it at checkout. This coupon is single-use.</p>';
                        $this->send_user_email( $user_email, $subject, $body );
                    }
                } else {
                    $result['error'] = 'coupon_creation_failed';
                }
                return $result;

            case 'product':
                $product_id = intval( $prize['product_id'] ?? 0 );
                if ( $product_id > 0 && class_exists( 'WC_Order' ) ) {
                    try {
                        $order = wc_create_order( [ 'customer_id' => $user_id ] );
                        $order->add_product( wc_get_product( $product_id ), 1 );
                        $order->set_prices_include_tax( true );
                        $order->calculate_totals();
                        $order->set_total( 0 );
                        $order->add_order_note( 'WCO Prize Order autogenerated for product prize.' );
                        $order->update_status( 'processing', 'Prize won via WCO.' );

                        $result['order_id'] = $order->get_id();
                        $result['product_id'] = $product_id;

                        if ( $user_email ) {
                            $subject = 'Congratulations — you won a prize';
                            $body  = '<p>Nice one — you won <strong>' . esc_html( $prize['label'] ?? 'a product' ) . '</strong>.</p>';
                            $body .= '<p>We have created an order for your prize (Order #: ' . intval($order->get_id()) . '). We will fulfill it shortly.</p>';
                            $order_view = esc_url( wc_get_endpoint_url( 'view-order', $order->get_id() ) );
                            $body .= '<p>View your prize order: <a href="' . $order_view . '">' . intval($order->get_id()) . '</a></p>';
                            $this->send_user_email( $user_email, $subject, $body );
                        }

                        return $result;
                    } catch ( Exception $e ) {
                        $result['error'] = 'order_creation_failed';
                        return $result;
                    }
                } else {
                    // fallback: notify admin to fulfill manually
                    wp_mail( get_option('admin_email'), 'WCO Prize Won (manual fulfil)', 'User ID ' . $user_id . ' won product ID ' . $product_id . ' from case ' . $case_id );
                    $result['notified_admin'] = true;
                    return $result;
                }

            default:
                return [ 'note' => 'No award action for this type.' ];
        }
    }

    private function send_user_email( $to, $subject, $html_body ) {
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        if ( function_exists( 'wc_mail' ) ) {
            wc_mail( $to, $subject, $html_body, $headers );
        } else {
            wp_mail( $to, $subject, $html_body, $headers );
        }
    }

    /**
     * Log a win.
     * $award is an array returned by award_prize() — will be stored inside prize_meta
     */
    public function log_win( $user_id, $case_id, $prize, $order_id = 0, $award = [] ) {
        global $wpdb;
        $table = $wpdb->prefix . 'wco_wins';
        $prize_payload = $prize;
        $prize_payload['award'] = $award;
        $fulfilled = 0;
        // mark fulfilled for coupons/credits (they are immediate)
        if ( in_array( $prize['type'] ?? '', [ 'coupon_fixed_cart', 'coupon_percent', 'credit' ] ) ) {
            $fulfilled = 1;
        }
        $wpdb->insert( $table, [
            'user_id' => $user_id,
            'case_id' => $case_id,
            'prize_label' => $prize['label'] ?? 'Prize',
            'prize_type'  => $prize['type'] ?? 'unknown',
            'prize_meta'  => maybe_serialize( $prize_payload ),
            'order_id'    => $award['order_id'] ?? 0,
            'fulfilled'   => $fulfilled,
            'created_at'  => current_time( 'mysql' )
        ] );
    }

    private function log_key_grant( $user_id, $order_id, $keys, $reason = '' ) {
        global $wpdb;
        $table = $wpdb->prefix . 'wco_key_grants';
        $wpdb->insert( $table, [
            'user_id' => $user_id,
            'order_id' => $order_id,
            'keys_awarded' => intval($keys),
            'reason' => sanitize_text_field($reason),
            'created_at' => current_time( 'mysql' )
        ] );
    }

    // === Keys ===
    public function add_keys( $user_id, $delta ) {
        $keys = intval( get_user_meta( $user_id, self::USER_KEYS_META, true ) );
        $keys = max( 0, $keys + intval($delta) );
        update_user_meta( $user_id, self::USER_KEYS_META, $keys );
        return $keys;
    }

    public function maybe_grant_keys( $order_id, $old_status, $new_status, $order ) {
        $opt = get_option( self::SETTINGS_OPTION, [] );
        $trigger = $opt['order_status_trigger'] ?? 'completed';
        if ( $new_status !== $trigger ) return;

        $user_id = $order->get_user_id();
        if ( ! $user_id ) return;

        $keys_to_add = 0; $reason = '';

        // 1) From qualifying purchase amount
        $qual = floatval( $opt['qualifying_amount'] ?? 10 );
        $order_total = floatval( $order->get_total() );
        if ( $qual > 0 ) {
            $from_total = floor( $order_total / $qual );
            if ( $from_total > 0 ) { $keys_to_add += intval($from_total); $reason = 'qualifying_amount'; }
        }

        // 2) From per-product key meta (optional legacy)
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product(); if ( ! $product ) continue;
            $k = intval( get_post_meta( $product->get_id(), '_wco_keys_per_purchase', true ) );
            $qty = intval( $item->get_quantity() );
            if ( $k > 0 && $qty > 0 ) { $keys_to_add += $k * $qty; $reason = 'product_meta'; }
        }

        // 3) From key pack sale (if enabled)
        if ( intval($opt['enable_key_sale'] ?? 0 ) === 1 ) {
            $pack_id = intval( $opt['key_pack_product'] ?? 0 );
            $per_pack = intval( $opt['keys_per_pack'] ?? 1 );
            foreach ( $order->get_items() as $item ) {
                $product = $item->get_product(); if ( ! $product ) continue;
                if ( $product->get_id() === $pack_id ) {
                    $qty = intval( $item->get_quantity() );
                    if ( $qty > 0 ) { $keys_to_add += $qty * $per_pack; $reason = 'key_pack'; }
                }
            }
        }

        if ( $keys_to_add > 0 ) {
            $new_total = $this->add_keys( $user_id, $keys_to_add );
            $order->add_order_note( sprintf( 'WCO: Granted %d key(s) (reason: %s). User now has %d.', $keys_to_add, $reason, $new_total ) );
            $this->log_key_grant( $user_id, $order_id, $keys_to_add, $reason );
        }
    }

    /**
     * Log a reward entry (coupon) to user meta.
     */
    private function log_reward_to_user( $user_id, $entry ) {
        if ( ! $user_id || empty( $entry['coupon_code'] ) ) {
            return;
        }
        $meta_key = '_wco_rewards';
        $existing = get_user_meta( $user_id, $meta_key, true );
        if ( ! is_array( $existing ) ) {
            $existing = [];
        }
        $entry['created_at'] = $entry['created_at'] ?? time();
        $existing[] = $entry;
        update_user_meta( $user_id, $meta_key, $existing );
    }

}